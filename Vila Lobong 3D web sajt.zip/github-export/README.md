# One Villa Ubud

Website for One Villa Ubud, Singakerta, Bali.

## Publish on GitHub Pages
1. Create a new repository and upload `index.html`.
2. Go to Settings → Pages.
3. Under "Branch", pick `main` and `/ (root)`, then Save.
4. The site will be live at `https://<username>.github.io/<repo>/` in a minute or two.

## Edit content
All villa info (text, prices, photos, booked dates, phone) is in the `CONFIG` object at the top of `index.html`.
